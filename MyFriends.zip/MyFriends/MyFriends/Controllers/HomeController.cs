﻿using Microsoft.AspNetCore.Mvc;
using System.Data.Entity;
using MyFriends.Models;
using MyFriends.ViewModels;
using System.Data.Entity.Core.Objects;
using System.Diagnostics;
using Microsoft.CodeAnalysis;

namespace MyFriends.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        public IActionResult Edit(int? id)
        {
            if(id == null) return RedirectToAction("Index");
            Friend friend = DataLayer.Data.Friends.Include(f => f.Images).ToList().Find(f => f.ID == id);
            if(friend == null) return RedirectToAction("Index");
            return View(friend);
        }

        [HttpPost,ValidateAntiForgeryToken]
        public IActionResult Edit(Friend friend)
        {
            if (friend == null) return RedirectToAction("Index");
            Friend friendDb = DataLayer.Data.Friends.ToList().Find(f=>f.ID == friend.ID);
            if(friendDb == null) return RedirectToAction("Index");
            friendDb.FirstName = friend.FullName;
            friendDb.LastName = friend.FullName;
            friendDb.PhoneNumber = friend.PhoneNumber;
            friendDb.EmailAddress = friend.EmailAddress;
            DataLayer.Data.SaveChanges();
            // ...
            return View(friendDb);

        }

        public IActionResult Details(int? id)
        {
            if (id == null) return RedirectToAction("Index");
            Friend friend = DataLayer.Data.Friends.Include(f => f.Images).ToList().Find(f => f.ID == id);
            if (friend == null) return RedirectToAction("Index");
            return View(friend);
        }

        public IActionResult Create()
        {
            VMCreateFriendWithImage VM = new VMCreateFriendWithImage();
            return View(VM);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Create(VMCreateFriendWithImage VM)
        {
            if (VM == null) return RedirectToAction("Index");
            VM.Friend.AddImage(VM.File);
            DataLayer.Data.Friends.Add(VM.Friend);
            DataLayer.Data.SaveChanges();
            return RedirectToAction(nameof(Index));
        }


        public IActionResult Index()
        {
            DataLayer data = DataLayer.Data;
            List<Friend> friends = data.Friends.Include(f=>f.Images).ToList();
            return View(friends);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}