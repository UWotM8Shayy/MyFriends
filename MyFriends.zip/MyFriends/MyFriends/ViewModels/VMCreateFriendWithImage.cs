﻿using MyFriends.Models;
using System.ComponentModel.DataAnnotations;
using System.Security.Policy;

namespace MyFriends.ViewModels
{
    public class VMCreateFriendWithImage
    {
        public VMCreateFriendWithImage() { Friend = new Friend(); }
        public Friend Friend { get; set; }
        [Display]
        public IFormFile File { get; set; }
        
    }
}
