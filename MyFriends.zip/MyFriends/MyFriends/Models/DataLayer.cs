﻿using System.Data.Entity;

namespace MyFriends.Models
{
    public class DataLayer :  DbContext
    {
        static DataLayer _data;
        private DataLayer():base("server = DESKTOP-SS0T7TL\\SHAYDBSQL; initial catalog = My_Friends_YD9; user id = sa; password = 1234")
        {
            Database.SetInitializer<DataLayer>(new DropCreateDatabaseIfModelChanges<DataLayer>());
            if(Friends.Count()== 0)
            {
                Seed();
            }
        }
        public static DataLayer Data
        {
            get
            {
                if(_data==null) _data = new DataLayer();
                return _data;
            }
        }

        private void Seed()
        {
            Friend friend = new Friend
            {
                FirstName = "שי",
                LastName = "גולדנברג",
                PhoneNumber = "0549909789",
                EmailAddress = "shay,gol55@gmail.com",
            };
            Friends.Add(friend);


            SaveChanges();
        }
        public DbSet<Friend> Friends { get; set; }
        public DbSet<Image> Images { get; set; }
    }
}
