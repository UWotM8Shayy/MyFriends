﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.ExceptionServices;

namespace MyFriends.Models
{
    public class Friend
    {
        public Friend() { Images = new List<Image>(); }
        [Key] // primay key plus 

        public int ID { get; set; }
        [Required,Display(Name = "שם פרטי")]
        public string FirstName { get; set; }

        [Display(Name = "שם משפחה")]
        public string LastName { get; set; }

        [NotMapped]
        [Display(Name = "שם")]
        public string FullName { get { if (FirstName == null) return ""; return FirstName + " " + LastName; } } 

        [Phone,Display(Name = "טלפון")]
        public string PhoneNumber { get; set; }

        [EmailAddress(ErrorMessage = " נא להכניס כתובת מייל נכונה")
            ,Display(Name = "מייל")]
        public string EmailAddress { get; set; }

        public List<Image> Images { get; set; }


        public void AddImage(IFormFile file)
        {
            if (file == null) return;
            MemoryStream stream = new MemoryStream();
            file.CopyTo(stream);
            AddImage(stream.ToArray());
        }

        public void AddImage(byte[] myImage)
        {
            Image image = new Image { Friend = this, MyImage = myImage };
            Images.Add(image);
        }

       
    }
}
